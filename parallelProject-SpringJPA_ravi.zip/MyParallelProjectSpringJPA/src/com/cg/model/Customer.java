package com.cg.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="CustomerOfSpringJPA")
public class Customer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	

	@Id
	@GeneratedValue(generator="se",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="se",sequenceName="se",initialValue=100,allocationSize=1)
	int cid;
	
	private String mobileno ;
	
	private String name;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "walletid")
	
	Wallet wallet;
	
	
	/*public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}*/
	
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String mobileno, String name ,Wallet wallet) {
		super();
		this.mobileno = mobileno;
		this.name = name;
		this.wallet=wallet;
	}

	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Customer [mobileno=" + mobileno + ", name=" + name + "]";
	}
	
	
	
	
}
