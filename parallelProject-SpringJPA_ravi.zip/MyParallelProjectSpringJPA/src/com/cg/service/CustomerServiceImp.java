package com.cg.service;


import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.CustomerDao;
import com.cg.dao.CustomerDaoImpl;
import com.cg.model.Customer;
import com.cg.model.Wallet;



@Service("customerService")
public class CustomerServiceImp implements CustomerService {

	@Autowired
	CustomerDao dao ;
	
	


	@Override
	public Customer createAccount(String mobileno, String name, BigDecimal amount) {
	
		
		Wallet newWallet = new Wallet();
		newWallet.setBalance(amount);
		
		Customer newCustomer= new Customer();
		
		newCustomer.setMobileno(mobileno);
		newCustomer.setName(name);
		newCustomer.setWallet(newWallet);
		
		Customer c = dao.findOne(mobileno);
		boolean status;
		
		if(c==null) {
			System.out.println("going to save");
			status = dao.save(newCustomer);
		}
			
		return newCustomer;
	}

	@Override
	public Customer showBalance(String mobileno) {
		
		Customer c = dao.findOne(mobileno);
		
		if(c!=null) {
			return c;
		}else {
		return null;
		}
	}

	@Override
	public Customer fundTransfer(String sourcemobileno, String targetmobileno, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer deposit(String mobileno, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer withdraw(String mobileno, BigDecimal amount) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer validate(String mobileno) {
		Customer c = dao.validate(mobileno);
		return c;
	}

	

	
	


}
