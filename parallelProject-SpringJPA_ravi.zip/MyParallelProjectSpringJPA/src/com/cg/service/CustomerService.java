package com.cg.service;

import java.math.BigDecimal;

import com.cg.model.Customer;
import com.cg.model.Wallet;

public interface CustomerService {

	
	public Customer createAccount(String mobileno, String name, BigDecimal amount);
	
	public Customer showBalance(String mobileno);
	
	public  Customer fundTransfer(String sourcemobileno, String targetmobileno, BigDecimal amount);
	
	public Customer deposit(String mobileno, BigDecimal amount);
	
	public Customer withdraw(String mobileno, BigDecimal amount);
	
	public Customer validate(String mobileno);
}
