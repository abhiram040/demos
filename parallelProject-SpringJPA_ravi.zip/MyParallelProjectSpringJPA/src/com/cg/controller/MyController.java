package com.cg.controller;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dao.CustomerDaoImpl;
import com.cg.model.Customer;
import com.cg.model.Wallet;
import com.cg.service.CustomerService;
import com.cg.service.CustomerServiceImp;

@Controller
public class MyController {

	
	@Autowired
	CustomerService customerService;
	
	

	@RequestMapping(value = "/loginlink", method = RequestMethod.GET)
	public String loginlink() {
		return "login";

	}
	
	
	@RequestMapping(value ="/customerform" , method = RequestMethod.GET)
	String showCustomerform(){
		
		return "customerform";     //under view folder for product u/I jsp
	}

	
	@RequestMapping("/loginvalidation")
	public ModelAndView login(HttpServletRequest request) {
		
		ModelAndView modelView = new ModelAndView();
		
		String mobileno = request.getParameter("mobileno");
		
		Customer customer=customerService.validate(mobileno);
		
		if (customer!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", customer);
			modelView.setViewName("Index");
		} else {
			modelView.addObject("status", "Invalid mobile number!!");
			modelView.setViewName("login");

		}
		return modelView;
	}
	

	
     @RequestMapping("/save")
	public ModelAndView addCustomer(HttpServletRequest request){
	     
    	 ModelAndView modelView = new ModelAndView();
    	 
    	 String name = request.getParameter("name");
 		String mobileno = request.getParameter("mobileno");
 		
 		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
 		
		Customer c= customerService.createAccount(mobileno, name, amount);
		

		if (c!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", c);
			modelView.setViewName("aftercustomerform");
		} else {
			System.out.println("already exists!!!");
			modelView.addObject("status", "mobile number already exists!!!!");
			modelView.setViewName("customerform");
		}
		return modelView;
     }
     
     
     
     
     
     @RequestMapping(value ="/balance" , method = RequestMethod.GET)
 	String showBlanceform(){
 		return "showbalance";     //under view folder for product u/I jsp
 	}
     @RequestMapping("/getBalance")
     public ModelAndView showBalance(HttpServletRequest request) {
    	 
    	 ModelAndView modelView = new ModelAndView();
    	 
    	 String mobileno = request.getParameter("mobileno");
    	 
    	 Customer c= customerService.showBalance(mobileno);
    	 
    	 if(c!=null) {
    		 System.out.println("balance is :"+c.getWallet().getBalance());
    		 HttpSession session = request.getSession();
 			session.setAttribute("user", c);
 			modelView.setViewName("aftershowbalance");
    	 }else {
    		 System.out.println("mobile number doesnot exists!!!");
 			modelView.addObject("status", "mobile number doesnot exists!!!!");
 			modelView.setViewName("showbalance");
    	 }
    	 return modelView;
     }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
}
