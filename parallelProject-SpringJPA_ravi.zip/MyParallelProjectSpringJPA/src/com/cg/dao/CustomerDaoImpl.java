package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Customer;


@Repository("dao")
public class CustomerDaoImpl implements  CustomerDao {


	@PersistenceContext           
	EntityManager entityManager;
	

	public EntityManager getEntityManager() {
		return entityManager;
	}
	public void setEntityManager(EntityManager entityManager) {
	
		this.entityManager = entityManager;
	}
	
	
	
	@Transactional
	@Override
	public boolean save(Customer c) {
		

		entityManager.persist(c);
		
		return true;
		
	
	}
	
	
	
	@Override
	public Customer findOne(String mobileno) {
		

		Query q= entityManager.createQuery("from Customer c where c.mobileno= ?1");
		q.setParameter(1, mobileno);
        q.setMaxResults(1);
				List <Customer> list1 = q.getResultList();
		
		Customer newcustomer = null;
		if(list1.size()>0) {
		   newcustomer=list1.get(0);
		}
		
		if(newcustomer!=null) {
			System.out.println("mobile number already exists!!!!");
			return newcustomer;
		}
		
		return null;
		
	}
	
	
	
	@Transactional
	@Override
	public boolean update(Customer c) {
		
		return false;
	}
	
	
	public Customer validate(String mobileno) {
		
		Query  q = entityManager.createQuery("from Customer c where c.mobileno=?1 ");
		q.setParameter(1, mobileno);

		q.setMaxResults(1);
		
		List<Customer> custlist=q.getResultList();
		
		Customer newCustomer=null;
		if(custlist.size()>0)
		{
			newCustomer=custlist.get(0);
		}
		if(newCustomer!=null)
		{
			return newCustomer;
		}
		return null;
	}
	

	
}
