package com.cg.dao;

import com.cg.model.Customer;

public interface CustomerDao {

	public boolean save(Customer c);
	
	public Customer findOne(String mobileno);
	
	public boolean update(Customer c);
	
	public Customer validate(String mobileno);
}
