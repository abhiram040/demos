package com.cg.paymentapp.service;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.paymentapp.beans.Customer;
import com.cg.paymentapp.beans.Wallet;
import com.cg.paymentapp.exception.InsufficientBalanceException;
import com.cg.paymentapp.repo.WalletRepo;
import com.cg.paymentapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tr = em.getTransaction();
	WalletRepo wp = new WalletRepoImpl();

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		// TODO Auto-generated method stub
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileno, w);
		wp.save(c);
		return c;
	}

	@Override
	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		if (wp.findOne(mobileno) != null) {
			System.out.println("Customer Balance:= " + wp.findOne(mobileno).getWallet().getBalance());
			return wp.findOne(mobileno);
		} else {
			return null;
		}
	
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		try {
			if (amount.compareTo(wp.findOne(sourceMobileNo).getWallet().getBalance()) > 0) {
				throw new InsufficientBalanceException("Balance in your account is less to transfer");
			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		if ((wp.findOne(targetMobileNo) != null)
				&& (amount.compareTo(wp.findOne(sourceMobileNo).getWallet().getBalance()) <= 0)) {
			tr.begin();
			BigDecimal bd1 = wp.findOne(targetMobileNo).getWallet().getBalance().add(amount);
			BigDecimal bd2 = wp.findOne(sourceMobileNo).getWallet().getBalance().subtract(amount);
			Wallet w1=wp.findOne(sourceMobileNo).getWallet();
			w1.setBalance(bd2);
			em.merge(w1);
			Wallet w2=wp.findOne(targetMobileNo).getWallet();
			w2.setBalance(bd1);
			em.merge(w2);
			tr.commit();
			System.out.println("funds transferred to " + targetMobileNo + " from " + sourceMobileNo);
			return wp.findOne(targetMobileNo);
		} else {
			System.out.println("no account available with " + targetMobileNo);
			return null;
		}
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		if (wp.findOne(mobileNo) != null) {
			tr.begin();
			BigDecimal bd = wp.findOne(mobileNo).getWallet().getBalance().add(amount);
			Wallet w1=wp.findOne(mobileNo).getWallet();
			w1.setBalance(bd);
			em.merge(w1);
			tr.commit();
			return wp.findOne(mobileNo);
		}
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		try {
			if (amount.compareTo(wp.findOne(mobileNo).getWallet().getBalance()) > 0) {
				throw new InsufficientBalanceException("Balance in your account is less to withdraw");
			}
		} catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		if (wp.findOne(mobileNo) != null && (amount.compareTo(wp.findOne(mobileNo).getWallet().getBalance()) <= 0)) {
			tr.begin();
			BigDecimal bd1 = wp.findOne(mobileNo).getWallet().getBalance().subtract(amount);
			Wallet w=wp.findOne(mobileNo).getWallet();
			w.setBalance(bd1);
			System.out.println("aoumt withdrawn from " + mobileNo + " is: " + amount);
			em.merge(w);
			tr.commit();
			return wp.findOne(mobileNo);
		}
		return null;
	}

}
