package com.cg.mypaymentapp.repo;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;

public class WalletRepoImpl implements WalletRepo {
	Map<String, Customer> userdetails = new HashMap<>();

	public WalletRepoImpl() {
		BigDecimal b = new BigDecimal("250");
		Wallet repo = new Wallet(b);

		Customer customer = new Customer("Abhiram", "9849558075", repo);
		userdetails.put(customer.getMobileNo(), customer);

		Customer customer2 = new Customer("Suraj", "9949146120", repo);
		userdetails.put(customer2.getMobileNo(), customer2);

		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean save(Customer customer) {
		if(userdetails.containsKey(customer.getMobileNo()))
		{
		System.out.println("this moblie number is already registered. Try to register with another mobile number");
           return false;
		}
		else{
			userdetails.put(customer.getMobileNo(), customer);
			System.out.println("new customer added");
			return true;
			
			
		}
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		Customer cc=userdetails.get(mobileNo);
		return cc;
	}

}
