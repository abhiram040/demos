package com.cg.mypaymentapp.repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

@Repository("walletRepo")
public class WalletRepoImpl implements WalletRepo {
	
	@PersistenceContext
	EntityManager entityManager;

	
	@Transactional
	public boolean save(Customer customer) {
		
		if (findOne(customer.getMobileNo()) != null) {
			System.out.println(" account already exits with this number");
			return false;
		} else {
			entityManager.persist(customer);
			System.out.println(" account created ");
			return true;
		}
	}
	
	@Transactional(rollbackFor=InvalidInputException.class,readOnly=false)
	@Override
	public Customer findOne(String mobileNo) {
		Customer customer = null;
		Query q = entityManager.createQuery("from Customer c where c.mobileNo=?1");
		q.setParameter(1, mobileNo);
		q.setMaxResults(1);
		List<Customer> custlist = q.getResultList();
		if (custlist.size() > 0) {
			customer = custlist.get(0);
		}
		if (customer != null) {
			return customer;
		} else {
			try {
				throw new InvalidInputException("No such record exists");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return customer;
		}
	}

	public List<Customer> getAllAccounts() {
		Query q=entityManager.createQuery("from Customer");
		List<Customer> list=q.getResultList();
		return list;
	}

	@Transactional(rollbackFor=InsufficientBalanceException.class)
	@Override
	public boolean Update(Wallet wallet) {
		entityManager.merge(wallet);
		return true;
	}

	
}
