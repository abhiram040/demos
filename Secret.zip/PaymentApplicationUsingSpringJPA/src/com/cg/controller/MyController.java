package com.cg.controller;

import java.math.BigDecimal;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;

@Controller
public class MyController {

	@Autowired
	WalletService walletService;

	@RequestMapping("/addform")
	public String addform() {
		return "addform";
	}

	@RequestMapping("/myhome")
	public String returnTo() {
		return "myhome";
	}

	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest request) {
		ModelAndView andView = new ModelAndView();
		String mobileno = request.getParameter("mobileno");
		Customer c = walletService.findOne(mobileno);
		if (c != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", c);
			andView.setViewName("myhome");
		} else {
			andView.setViewName("loginpage");
			andView.addObject("status", "User doesnot exist");
		}
		return andView;
	}

	@RequestMapping("/loginpage")
	public String loginlink() {
		return "loginpage";
	}

	@RequestMapping("/save")
	public String addProduct(HttpServletRequest request) {
		String name = request.getParameter("name");
		String mobileno = request.getParameter("mobileno");
		BigDecimal amount = new BigDecimal(request.getParameter("balance"));
		System.out.println(mobileno);
		walletService.createAccount(name, mobileno, amount);
		return "redirect:/myhome";
	}

	@RequestMapping("/withdrawform")
	public String withdraw() {
		return "withdrawform";
	}

	@RequestMapping("/withdraw")
	public ModelAndView withDraw(HttpServletRequest request) {

		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		String mobileno = cus.getMobileNo();
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));

		Customer c = walletService.withdrawAmount(mobileno, amount);
		modelView.setViewName("withdrawform");
		if (c != null) {
			modelView.addObject("status", "withdraw successful");

		} else {

			modelView.addObject("status", "less amount to withdraw");
		}

		return modelView;

	}

	@RequestMapping("/depositform")
	public String deposit() {
		return "depositform";
	}

	@RequestMapping("/deposit")
	public ModelAndView depoSit(HttpServletRequest request) {

		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
		walletService.depositAmount(cus.getMobileNo(), amount);
		modelView.addObject("status1", "deposit successful");
		modelView.setViewName("depositform");
		return modelView;

	}

	@RequestMapping("/showbalanceform")
	public ModelAndView shoBal(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		ModelAndView modelView = new ModelAndView();
		Customer c1=walletService.showBalance(cus.getMobileNo());
		modelView.setViewName("showbalanceform");
		if(c1!=null) {
			session = request.getSession();
			session.setAttribute("user", c1);
		}
		return modelView;
	}

	@RequestMapping("/fundtransferform")
	public String fundTransfer() {
		return "fundtransferform";
	}

	@RequestMapping("/fundtransfer")
	public ModelAndView fundTrans(HttpServletRequest request) {
		ModelAndView modelView = new ModelAndView();
		HttpSession session = request.getSession();
		Customer cus = (Customer) session.getAttribute("user");
		String targetmobileno = request.getParameter("targetmobileno");
		BigDecimal amount = new BigDecimal(request.getParameter("amount"));
		Customer c1 = walletService.fundTransfer(cus.getMobileNo(), targetmobileno, amount);
		modelView.setViewName("fundtransferform");
		if (c1 != null) {
			modelView.addObject("status1", "funds transfered from " + cus.getMobileNo() + " to " + targetmobileno);
		} else {
			modelView.setViewName("fundtransferform");
		}
		return modelView;
	}
	

	@RequestMapping("/logout")
	public ModelAndView logOut(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return new ModelAndView("/loginpage");
	}
	
}
