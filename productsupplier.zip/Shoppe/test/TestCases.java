import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.is.service.ISuperShoppeService;
import com.cg.is.service.SuperShoppeServiceImpl;

public class TestCases {
    ISuperShoppeService s;
	@Before
	public void setup(){
		s=new SuperShoppeServiceImpl();
	}
	@Test
	public void addproduct() {
		int i=s.addProduct("toy", 4000, 2);
		
		assertTrue(i==0);
	}
	
	
	@After
	public void tearDown(){
		s=null;
	}

}
