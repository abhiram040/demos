package com.cg.is.service;

import java.util.HashMap;

import com.cg.is.beans.Product;
import com.cg.is.beans.Supplier;
import com.cg.is.dao.SuperShoppeDao;
import com.cg.is.dao.SuperShoppeDaoImpl;

public class SuperShoppeServiceImpl implements ISuperShoppeService {
	SuperShoppeDao shop=new SuperShoppeDaoImpl(); 

	@Override
	public int addProduct(String productname,double price,int quantity) {
		Product p1=new Product();
		p1.setProductName(productname);
		
		p1.setPrice(price);
		p1.setQuantity(quantity);
		
		// TODO Auto-generated method stub
		return shop.addProduct(p1);
	}

	@Override
	public int addSupplier(String suppliername,String address,String mobileno) {
		// TODO Auto-generated method stub
		Supplier s1=new Supplier();
		s1.setName(suppliername);
		s1.setAddress(address);
		s1.setMobileNo(mobileno);
		return shop.addSupplier(s1);
	}

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return shop.getAllProducts();
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		// TODO Auto-generated method stub
		return shop.getAllSuppliers();
	}

}
