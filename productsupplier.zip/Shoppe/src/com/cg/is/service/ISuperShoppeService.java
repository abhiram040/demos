package com.cg.is.service;

import java.util.HashMap;

import com.cg.is.beans.*;;

public interface ISuperShoppeService {
	
	
	public HashMap<Integer,Product> getAllProducts();
	public HashMap<Integer,Supplier> getAllSuppliers();
	int addProduct(String productname, double price, int quantity);
	int addSupplier(String suppliername, String address, String mobile);

}
