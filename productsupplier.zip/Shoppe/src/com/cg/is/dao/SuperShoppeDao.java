package com.cg.is.dao;

import java.util.HashMap;
import com.cg.is.beans.*;
public interface SuperShoppeDao {
	public int addProduct(Product product);
	public int addSupplier(Supplier sup);
	public <Product> HashMap<Integer,Product> getAllProducts();
	public HashMap<Integer,Supplier> getAllSuppliers();

}
