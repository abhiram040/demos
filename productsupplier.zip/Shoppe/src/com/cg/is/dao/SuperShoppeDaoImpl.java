package com.cg.is.dao;

import java.util.HashMap;
import com.cg.is.beans.*;
import java.util.Map;


public class SuperShoppeDaoImpl implements SuperShoppeDao {
	private HashMap<Integer,Product> pro=new HashMap<>();
	private HashMap<Integer,Supplier> sp=new HashMap<>();
	
	

	

	@Override
	public HashMap<Integer, Product> getAllProducts() {
		// TODO Auto-generated method stub
		return pro;
	}

	@Override
	public HashMap<Integer, Supplier> getAllSuppliers() {
		// TODO Auto-generated method stub
		return sp;
	}

	@Override
	public int addSupplier(Supplier sup) {
		sp.put(sup.getSupplierId(), sup);
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addProduct(Product product) {
		if(product!=null){
		pro.put(product.getProductId(), product);
		return 1;
		}
		else{
			return 0;
		}
		
	}

}
