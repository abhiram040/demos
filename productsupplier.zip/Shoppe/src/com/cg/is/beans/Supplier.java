package com.cg.is.beans;

public class Supplier {
	private int supplierId=(int)(Math.random()*100);
	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", name=" + name + ", mobileNo=" + mobileNo + ", address="
				+ address + "]";
	}
	public Supplier() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String name ;
	private String mobileNo;
	private String address;
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
