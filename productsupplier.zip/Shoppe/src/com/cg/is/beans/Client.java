package com.cg.is.beans;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.is.service.*;

public class Client {
	public static void main(String[] args) {
		ISuperShoppeService service = new SuperShoppeServiceImpl();
		String productName, name, mobileNo, address, Suppliername;
		int quantity;
		double price;
		//char ch;
		do {
			System.out.println(
					"1)create product list\t2)create supplier list\t3)display product list\t4)display supplier list");
			Scanner in = new Scanner(System.in);
			int choice = in.nextInt();
			switch (choice) {
			case 1:
				System.out.println("enter the product name");
				productName = in.next();
				System.out.println("enter the quantity");
				quantity = in.nextInt();
				System.out.println("enter the price");
				price = in.nextDouble();
				service.addProduct(productName, price, quantity);
				break;
			case 2:
				System.out.println("enter the supplier name");
				Suppliername = in.next();
				System.out.println("enter the mobile");
				mobileNo = in.next();
				System.out.println("enter the address");
				address = in.next();
				service.addSupplier(Suppliername, address, mobileNo);
				break;
			case 3:
			 HashMap<Integer, Product>mp=service.getAllProducts();
			 for(Product e:mp.values())
			 {
				 System.out.println(e);
			 }
			 break;
			case 4:
				HashMap<Integer, Supplier>sp=service.getAllSuppliers();
				for(Supplier f:sp.values())
				 {
					 System.out.println(f);
				 }
				 break;
			}//System.out.println("press y to continue...");
			//ch = in.next().charAt(0);
		} while (true);
	}
}
