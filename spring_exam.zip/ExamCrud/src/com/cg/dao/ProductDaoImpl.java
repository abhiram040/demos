package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Product;

@Repository("productDao")
public class ProductDaoImpl implements ProductDao {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional
	@Override
	public boolean save(Product product) {
		// TODO Auto-generated method stub
		entityManager.persist(product);
		Product newproduct=entityManager.find(Product.class,product.getPid());
				if(newproduct!=null)
					
		return true;
				else
					return false;
	}
	
	@Transactional
	@Override
	public boolean delete(int pid) {
		// TODO Auto-generated method stub
		Product p=entityManager.find(Product.class,pid);
		entityManager.remove(p);
		return true;
	}

	@Transactional
	@Override
	public boolean update(Product product) {
		// TODO Auto-generated method stub
		entityManager.merge(product);
		return true;
	}

	@Override
	public Product getById(int pid) {
		// TODO Auto-generated method stub
		Product p=entityManager.find(Product.class,pid);
		return p;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		Query q=entityManager.createQuery("from Product");
		List<Product> list=q.getResultList();
		return list;
	}

}
