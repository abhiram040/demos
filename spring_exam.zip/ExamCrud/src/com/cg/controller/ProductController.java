package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.dao.ProductDao;
import com.cg.model.Product;

@Controller
public class ProductController {
	@Autowired
	ProductDao productDao;

	@RequestMapping("/productform")
	public String showproductform(Model m) {
		Product p = new Product();
		m.addAttribute("command",p);
		return "productform";

	}

	@RequestMapping("/save")
	public String addProduct(@ModelAttribute("product") Product product) {
		productDao.save(product);
		return "redirect:/viewproduct";
               
	}
	@RequestMapping("/viewproduct")
	public String viewallProduct(Model m) {
		List<Product> productlist=productDao.getAllProducts();
		m.addAttribute("plist",productlist);
		return "viewproduct";
		
	}

}
