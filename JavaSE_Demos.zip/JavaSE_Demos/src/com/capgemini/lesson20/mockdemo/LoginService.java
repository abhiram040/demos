package com.capgemini.lesson20.mockdemo;

public interface LoginService {
boolean login(String username, String password);
}
