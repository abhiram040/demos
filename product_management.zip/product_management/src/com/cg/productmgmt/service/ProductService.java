package com.cg.productmgmt.service;

import java.util.Map;

import com.cg.productmgmt.dao.IProductDAO;
import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService {
	IProductDAO productdao = new ProductDAO();

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub

		if (productdao.updateProducts(Category, hike) == 1) {
			return 1;
		}
		return 0;
	}

	@Override
	public Map<String, String> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productdao.getProductDetails();
	}

	public Map<String, Integer> getSalesDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productdao.getSalesDetails();
	}

}
