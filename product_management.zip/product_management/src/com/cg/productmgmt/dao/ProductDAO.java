package com.cg.productmgmt.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.beans.Product;
import com.cg.productmgmt.exception.ProductException;

public class ProductDAO implements IProductDAO {

	Map<String, String> productDetails = new HashMap<>();
	Map<String, Integer> salesDetails = new HashMap<>();

	public ProductDAO() {
		// TODO Auto-generated constructor stub
		Product product1 = new Product("lux", "soap", 100);
		productDetails.put(product1.getCategory(), product1.getProductname());
		salesDetails.put(product1.getProductname(), product1.getPrice());

		Product product2 = new Product("sony", "electronics", 200);
		productDetails.put(product2.getCategory(), product2.getProductname());
		salesDetails.put(product2.getProductname(), product2.getPrice());

	}

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub

		if (productDetails.get(Category) != null) {

			salesDetails.put(productDetails.get(Category),
					(int) (salesDetails.get(productDetails.get(Category)) * (1 + 0.01 * hike)));
			return 1;
		}

		return 0;
	}

	@Override
	public Map<String, String> getProductDetails() throws ProductException {
		// TODO Auto-generated method stub
		return productDetails;
	}

	public Map<String, Integer> getSalesDetails() throws ProductException {
		// TODO Auto-generated method stub
		return salesDetails;
	}

}
