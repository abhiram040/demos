package com.cg.productmgmt.exception;

public class ProductException extends Exception{

	public ProductException() {
		// TODO Auto-generated constructor stub
	}
}
