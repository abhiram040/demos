package com.cg.productmgmt.beans;

public class Product {
 private String productname;
 private String category;
 
 private int price;
 public Product() {
	// TODO Auto-generated constructor stub
}
 
public Product(String productname, String category, int price) {
	super();
	this.productname = productname;
	this.category = category;
	this.price = price;
}

public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}

@Override
public String toString() {
	return "Product [productname=" + productname + ", category=" + category  + "]";
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
 
}

