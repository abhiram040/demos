package com.cg.productmgmt.ui;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cg.productmgmt.exception.ProductException;
import com.cg.productmgmt.service.IProductService;
import com.cg.productmgmt.service.ProductService;

public class Client {
public static void main(String[] args) throws ProductException {
	IProductService service=new ProductService();
	Scanner sc=new Scanner(System.in);
	int ch=0;
	Map<String,String> productdetails=null;
	Map<String,Integer> salesdetails=null;
	
	do{
		System.out.println("Enter your choice");
		System.out.println("1: Update Product price:");
		System.out.println("2: Exit");
		ch=sc.nextInt();
		switch(ch){
		
		case 1:
			System.out.println("Enter Product Category");
			String category=sc.next();
			System.out.println("Enter Product Hike");
			int hike=sc.nextInt();
			if(service.updateProducts(category, hike)==1){
				productdetails=service.getProductDetails();
				salesdetails=service.getSalesDetails();
				System.out.println("updated"+salesdetails.get(productdetails.get(category)));
			}
			else{
				System.out.println("not updated");
			}
			break;
		case 2:
			System.exit(0); break;
            }
}while(true);
}
}
