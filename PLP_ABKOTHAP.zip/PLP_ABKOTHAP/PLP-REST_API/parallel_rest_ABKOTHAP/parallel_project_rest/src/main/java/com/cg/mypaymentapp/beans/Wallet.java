package com.cg.mypaymentapp.beans;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Entity
@Component
@Table(name="Walletboot")
public class Wallet implements Serializable{
	@Id
	@GeneratedValue(generator="wal1",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="wal1",sequenceName="walboot",initialValue=100,allocationSize=1)
	private int walletid;
	
	private BigDecimal balance;
	

	

	public int getWalletid() {
		return walletid;
	}

	public void setWalletid(int walletid) {
		this.walletid = walletid;
	}

	public Wallet() {
		// TODO Auto-generated constructor stub
	}

	public Wallet(BigDecimal amount) {
		this.balance = amount;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "  balance=" + balance;
	}

}
