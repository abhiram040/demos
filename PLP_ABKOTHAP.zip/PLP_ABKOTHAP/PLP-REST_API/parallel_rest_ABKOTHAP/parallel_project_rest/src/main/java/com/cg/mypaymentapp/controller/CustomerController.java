package com.cg.mypaymentapp.controller;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.service.WalletService;

@RestController
@RequestMapping("/rest")
public class CustomerController 
{
	@Autowired
	WalletService walletService;
	
	Customer customer=null,customer1=null;
	
	public CustomerController() {
		System.out.println("controller-constructor");
	}
/*
@GetMapping("/create?name={name};mobile={mobile};balance={balance}")
	public Customer create(@Rquestparam("name") String name,@Rquestparam("mobile") String mobile,@Rquestparam("balance") BigDecimal balance)
	{

*/
	
	@GetMapping("/create")
	public Customer create(@RequestParam("name") String name,@RequestParam("mobile") String mobile,@RequestParam("balance") BigDecimal balance)
	{
		System.out.println("create");
		Customer c=walletService.createAccount(name,mobile,balance);
		
		return c;
	}

	@GetMapping("/login")
	public String login(@RequestParam("mobile") String mobile) {
	
		System.out.println("login");
		
		customer=walletService.validate(mobile);
		if(customer!=null)
		return "Login successfully";
		else
		return "Invalid mobile number!!";	
	}
	
	@GetMapping("/showbalance")
	public BigDecimal showbalance(@RequestParam("mobile") String mobile)
	{
		customer=walletService.validate(mobile);
		if(customer!=null)
		{
			customer=walletService.showBalance(mobile);
		return customer.getWallet().getBalance();
		}
		else
		return null;
	}
	
	@GetMapping("/fundtransfer")
	public String fundtransfer(@RequestParam("sourcemobile") String sourcemobile,@RequestParam("targetmobile") String targetmobile,@RequestParam("balance") BigDecimal amount)
	{
		
		customer=walletService.validate(sourcemobile);
		customer1=walletService.validate(targetmobile);
		if(customer!=null&&customer1!=null)
		{
		BigDecimal walletbal1 = customer.getWallet().getBalance();
		int res=walletbal1.compareTo(amount);
		if(res==1)
		{
		Customer c=walletService.fundTransfer(sourcemobile,targetmobile,amount);
		return "Fund Transfered sucessfully....";
		}
		else
		{
	        return "Insufficient balance";
		}
		}
		else
		{
			return "Source or Target mobile number does not have account in mypayment application!";
		}
	}
	@GetMapping("/deposit")
	public  String  deposit(@RequestParam("mobile") String mobile,@RequestParam("amount") BigDecimal amount)
	{
		customer=walletService.validate(mobile);
		if(customer!=null)
		{
		customer=walletService.depositAmount(mobile, amount);
		return "Deposited successfully....";
		}
		else
		{
			return "Invalid mobile number";
		}
	}

	@GetMapping("/withdraw")
	public String withdraw(@RequestParam("mobile") String mobile,@RequestParam("amount") BigDecimal amount)
	{
		customer=walletService.validate(mobile);
		if(customer!=null)
		{
		BigDecimal walletbal1 = customer.getWallet().getBalance();
		int res=walletbal1.compareTo(amount);
		if(res==1)
		{
			customer=walletService.withdrawAmount(mobile, amount);
			return "Withdraw Successfully...";
		}
		else
		{
			return  "Insufficient balance";
		}
		}
		else
		{
			return "Invalid mobile number";
		}
	}
	@GetMapping("/viewprofile")
	public String viewprofile(@RequestParam("mobile") String mobile)
	{
		customer=walletService.validate(mobile);
		System.out.println(customer);
		String name=customer.getName();
		BigDecimal walletbal1 = customer.getWallet().getBalance();
		return "name :"+customer.getName()+"\nBalance :"+walletbal1;
	}
}
