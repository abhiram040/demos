package com.cg.mypaymentapp.repo;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletRepoImpl implements WalletRepo {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
	EntityManager em = emf.createEntityManager();
	EntityTransaction tr = em.getTransaction();

	@Override
	public boolean save(Customer customer) {
		if (findOne(customer.getMobileNo()) != null) {
			System.out.println(" account already exits with this number");
			return false;
		} else {
			tr.begin();
			em.persist(customer);
			System.out.println(" account created ");
			tr.commit();
			return true;
		}
	}

	@Override
	public Customer findOne(String mobileNo) {
		Customer customer = null;
		Query q = em.createQuery("from Customer where mobileNo=?1");
		q.setParameter(1, mobileNo);
		q.setMaxResults(1);
		List<Customer> custlist = q.getResultList();
		if (custlist.size() > 0) {
			customer = custlist.get(0);
		}
		if (customer != null) {
			return customer;
		} else {
			try {
				throw new InvalidInputException("No such record exists");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			return null;
		}
	}
}
