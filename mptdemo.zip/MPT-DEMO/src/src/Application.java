package src;

import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import src.com.capgemini.beans.*;
//import com.capgemini.service.CustomerService;
//import com.capgemini.service.CustomerServiceImple;
import src.com.capgemini.repository.*;
import src.com.capgemini.service.*;

public class Application {
	public static void main(String[] args) {
		CustomerService service;
		service = new CustomerServiceImple();
		List<Customer> customers = service.findAll();
		for (Customer customer : service.findAll()) {
			// System.out.println();
			System.out.println(customer);
			System.out.println();
		}
		System.out.println("---------------------------------------");
		service.delete(2);
		Customer customer4 = new Customer();
		customer4.setFirstname("shivani");
		customer4.setLastname("singetam");
		service.create(customer4);
		System.out.println("---------------------------------------");
		for (Customer customer : service.findAll()) {
			// System.out.println();
			System.out.println(customer);
			System.out.println();
		}
		
		Customer customer5 = new Customer();
		customer5.setFirstname("sangeetha");
		customer5.setLastname("singetam");
		service.update(3, customer5);
		System.out.println("---------------------------------------");
		for (Customer customer : service.findAll()) {
			// System.out.println();
			System.out.println(customer);
			System.out.println();
	}
}
}
