package src.com.capgemini.service;

import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import src.com.capgemini.beans.Customer;
import src.com.capgemini.repository.CustomerRepository;
import src.com.capgemini.repository.InMemoryCustomerRepository;

public class CustomerServiceImple implements CustomerService {
	private CustomerRepository repository;
	public CustomerServiceImple(){
		repository=new InMemoryCustomerRepository();
	}
	@Override
	public List<Customer> findAll() {
		
		return repository.findAll();
	}
	@Override
	public boolean delete(int id) {
		
		return repository.delete(id);
	}
	@Override
	public boolean create(Customer customer) {
	return repository.create(customer);
		
	}
	@Override
	public boolean update(int id, Customer c) {
		return repository.update(id,c);
	}

}
