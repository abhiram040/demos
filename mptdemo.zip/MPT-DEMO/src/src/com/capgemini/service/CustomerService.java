package src.com.capgemini.service;

import java.util.*;

import src.com.capgemini.beans.*;

public interface CustomerService {
	List<Customer> findAll();
	public boolean delete(int id);
	public boolean create(Customer customer);
	public boolean update(int id,Customer c);

}
