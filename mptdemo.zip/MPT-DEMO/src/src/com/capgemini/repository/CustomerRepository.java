package src.com.capgemini.repository;

import java.util.List;
import java.util.Map;

import src.com.capgemini.beans.Customer;

public interface CustomerRepository {
	List<Customer> findAll();
	public boolean delete(int id);
	public boolean create(Customer customer);
public boolean update(int id,Customer c);

}
