package src.com.capgemini.repository;

import java.util.*;

import src.com.capgemini.beans.ArtificialSortCustomer;
import src.com.capgemini.beans.Customer;

public class InMemoryCustomerRepository implements CustomerRepository {

/*1  */ private Map<Integer,Customer> customerEntries= new TreeMap<Integer,Customer>();;
	

	public InMemoryCustomerRepository() {
	
		Customer customer1=new Customer();
		customer1.setFirstname("bhavani");
		customer1.setLastname("singetam");
	//	customers.add(customer1);
		customerEntries.put(1,customer1);
		Customer customer2=new Customer();
		customer2.setFirstname("amrutha");
		customer2.setLastname("pathi");
	//	customers.add(customer2);
		customerEntries.put(2,customer2);
		Customer customer3=new Customer();
		customer3.setFirstname("aswin");
		customer3.setLastname("srinivasan");
		//customers.add(customer3);
		customerEntries.put(3,customer3);
		Customer customer4=new Customer();
		customer4.setFirstname("avinash");
		customer4.setLastname("korada");
		//customers.add(customer4);
		customerEntries.put(4,customer4);
	//	Collections.sort(customers,new ArtificialSortCustomer());
	}

	@Override
	public List<Customer> findAll(){
	List<Customer> customerl=new ArrayList<>(customerEntries.values());
	Collections.sort(customerl,new ArtificialSortCustomer());
		return customerl;
	}
	@Override
	public boolean delete(int id) {
		Customer c=customerEntries.remove(id);
		System.out.println(c+ "is removed");
		if(c!=null)
		{
			return true;
		}
		
		return false;
	}
	int count=5;
	@Override
		public boolean create(Customer customer) {
		Customer c=customerEntries.put(count++,customer);
		if(c!=null)
			return true;
		
			return false;
		}

	@Override
	public boolean update(int id, Customer c) {
		Customer co=customerEntries.put(id,c);
		//Customer c=customerEntries.put(id,c);
		if(c!=null)
			return true;
		return false;
	}

}
