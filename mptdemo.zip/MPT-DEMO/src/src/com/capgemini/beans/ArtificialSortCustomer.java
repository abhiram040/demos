package src.com.capgemini.beans;

import java.util.Comparator;

public class ArtificialSortCustomer implements Comparator<Customer>{
	

	@Override
	public int compare(Customer o1, Customer o2) {
		int diff=0;
		diff=((Customer)o1).firstname.compareTo(((Customer)o2).firstname);
		
		return diff;
	}

}
