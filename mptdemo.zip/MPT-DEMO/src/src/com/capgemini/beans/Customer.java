package src.com.capgemini.beans;

//import java.util.Collections;
//import java.util.List;

public class Customer implements Comparable<Object>{
	protected String firstname;
	protected String lastname;

	public Customer() {

	}

/*public boolean equals(Object obj) {

	return ;
}*/
	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String toString(){
		return firstname+"\n"+lastname;
	}
	

	@Override
	public int compareTo(Object o) {
		
	int diff=0;
	diff=this.lastname.compareTo(((Customer)o).getLastname());
	return diff;
	}

}
