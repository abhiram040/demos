import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
//import static org.junit.Test;






import src.com.capgemini.beans.Customer;
import src.com.capgemini.repository.CustomerRepository;
import src.com.capgemini.repository.InMemoryCustomerRepository;



public class TestStringOperation {
private CustomerRepository rep;
@Before
public void setup()
{
	rep=new InMemoryCustomerRepository();
}
@Test
public void TestCustomerRepository()
{
	Customer customer4 = new Customer();
	customer4.setFirstname("manasa");
	customer4.setLastname("nandigama");
      rep.create(customer4);
	Customer customer5 = new Customer();
	customer5.setFirstname("manasa");
	customer5.setLastname("nandigama");
	assertTrue(rep.findAll().contains(customer5));

}
public void findAll(){
	int size;
	size=rep.findAll().size();
	assertEquals(4,size);
}
@After
public void tearDown(){
	rep=null;
}
	@Test
	@Ignore
	public void test() {
		//fail("Not yet implemented");
		String msg="hello world!";
		String msg2=new String("hello world!");
		
		assertTrue(msg.length()>0);
		assertEquals(msg2,msg);
		assertSame(msg2,msg);	
		msg=null;
	}

}
